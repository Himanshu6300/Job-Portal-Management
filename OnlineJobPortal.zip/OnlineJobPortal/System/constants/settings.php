<?php
$actual_link = $_SERVER['HTTP_HOST'];

$default_timezone = '';
$smtp_host = '';
$smtp_user = '';
$smtp_pass = '';

$contact_mail = '';

$fb  = '#';
$tw = '#';
$ig = '#';
?>